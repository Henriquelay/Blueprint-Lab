data.raw["item"]["electric-energy-interface"].subgroup = "storage"
data.raw["item"]["electric-energy-interface"].order = "[storage-tank]a-b[electric-energy-interface]"

data.raw["item"]["infinity-chest"].subgroup = "storage"
data.raw["item"]["infinity-chest"].order = "a[electric-energy-interface]-b[infinity-chest]"

data.raw["item"]["infinity-pipe"].subgroup = "storage"
data.raw["item"]["infinity-pipe"].order = "a[infinity-chest]-b[infinity-pipe]"
